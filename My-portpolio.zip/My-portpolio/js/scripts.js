// Form Validation
document.getElementById('contact-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (name && emailPattern.test(email) && message) {
        document.getElementById('thank-you-message').style.display = 'block';
    } else {
        alert('Please fill out the form correctly.');
    }
});
